Modgen Classic Sonic README:
Modgen Classic Sonic 自述:
This module has been repaired from the original package and released
Repair content:
Fix the garbled code displacement in the SUPER SONIC modeling of the original package
Fix the missing KNUCKLES and EGGMAN modeling in the original package.
此模组由原包修复后发布
修复内容:
修复原包SUPER SONIC建模出现的乱码位移
修复原包缺失的KNUCKLES和EGGMAN建模
Modgen Classic Sonic(SONIC.EXE)README:
Modgen Classic Sonic(SONIC.EXE)自述:
This mod was released as a modification of the original package
Modifications:
The modeling of SONIC has been changed to the modeling of the SONIC.EXE, and everything else remains unchanged
此模组由原包修改后发布
修改内容:
修改模组SONIC建模为SONIC.EXE,其他没有改变
